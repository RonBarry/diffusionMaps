context("Testing density estimation on a small lattice")

test_that("Simple check of density",{
  test_latt = spam(0,nrow=4,ncol=4)
  test_latt[1,2] = 1
  test_latt[2,3] = 1
  test_latt[3,4] = 1
  test_latt[4,1] = 1
  test_latt = test_latt + t(test_latt)
  image(test_latt)
  nodelocs = matrix(ncol=3,byrow=TRUE,
                    c(10,10,0,10,20,0,20,20,0,20,10,0))
  plot(nodelocs,pch=c(1,2,3,4))
  locs = matrix(ncol=3,byrow=TRUE,
                c(11,11,0,21,21,0,21,21,0,21,21,0))
  #
  T = makeTranMatrix(test_latt, M=0.5)
  out_k1 = nparDensity(T, nodelocs, locs, k = 1)
  true_mat_k1 = structure(c(10, 10, 20, 20, 10, 20, 20, 10,
              0, 0, 0, 0, 0.125,
              0.25, 0.375, 0.25), .Dim = c(4L, 4L),
              .Dimnames = list(NULL,c("x", "y", "z", "prob")))
  out_k50 = nparDensity(T, nodelocs=nodelocs, locs=locs, k=50)
  true_mat_k50 = structure(c(10, 10, 20, 20, 10, 20, 20, 10, 0,
                0, 0, 0, 0.25, 0.25, 0.25, 0.25), .Dim = c(4L, 4L),
                .Dimnames = list(NULL, c("x", "y", "z", "prob")))
  #
  expect_equal(out_k1,true_mat_k1)
  expect_equal(out_k50,true_mat_k50)

})
