context("Test of crossvalidation of density")

test_that("Simple check of crossvalidation",{
  test_latt = spam(0,nrow=4,ncol=4)
  test_latt[1,2] = 1
  test_latt[2,3] = 1
  test_latt[3,4] = 1
  test_latt[4,1] = 1
  test_latt = test_latt + t(test_latt)
  image(test_latt)
  nodelocs = matrix(ncol=3,byrow=TRUE,
                    c(10,10,0,10,20,0,20,20,0,20,10,0))
  plot(nodelocs,pch=c(1,2,3,4))
  locs = matrix(ncol=3,byrow=TRUE,
                c(11,11,0,11,21,0,21,21,0,21,21,0))
  #
  T = makeTranMatrix(test_latt, M=0.5)
  out_ucv = crossvalNparDensity(T=T, nodelocs=nodelocs, locs=locs,
                               k_max = 10)
  expect_equal(out_ucv$k,10)
})
