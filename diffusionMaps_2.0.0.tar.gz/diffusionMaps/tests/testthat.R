library(testthat)
library(diffusionMaps)

test_check("diffusionMaps")
