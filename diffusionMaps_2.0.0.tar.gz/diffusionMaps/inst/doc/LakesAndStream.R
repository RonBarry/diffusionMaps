## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(rgdal)
library(RANN)
library(spam)
library(diffusionMaps)
library(colorspace)
library(sp)

## ----dat----------------------------------------------------------------------
cottonwood = 
matrix(ncol=2,byrow=TRUE,
c(-149.303960,61.604405, 
-149.303446,61.603752,
-149.303789,61.603098, 
-149.304990,61.602527, 
-149.304990,61.601711, 
-149.303102,61.601302, 
-149.302587,61.600649, 
-149.303274,61.599669, 
-149.304647,61.598118, 
-149.306535,61.597302, 
-149.308595,61.596730, 
-149.309969,61.595832, 
-149.311514,61.595015, 
-149.314432,61.595179, 
-149.317693,61.595832, 
-149.320783,61.595995, 
-149.323358,61.595913, 
-149.323530,61.595342, 
-149.325075,61.595097, 
-149.327306,61.595342, 
-149.328851,61.595179, 
-149.330225,61.594444, 
-149.330225,61.593545, 
-149.331598,61.593055, 
-149.334345,61.593300, 
-149.336061,61.594362, 
-149.337434,61.594852, 
-149.336919,61.596322, 
-149.336404,61.597138, 
-149.336576,61.598118, 
-149.334860,61.598853, 
-149.333658,61.599669, 
-149.331598,61.599669, 
-149.329195,61.599180, 
-149.327821,61.599343, 
-149.326448,61.599751, 
-149.323702,61.599914, 
-149.321985,61.599833, 
-149.319582,61.600323, 
-149.318037,61.600078, 
-149.315633,61.599996, 
-149.313917,61.599833, 
-149.313059,61.600486, 
-149.311170,61.601221, 
-149.309625,61.601792, 
-149.309625,61.602445, 
-149.308424,61.603098, 
-149.306879,61.604078))
cotton_island = matrix(ncol=2,byrow=TRUE,
c(-149.326791,61.598853, 
-149.326448,61.598445, 
-149.326791,61.597955, 
-149.327306,61.597302, 
-149.328508,61.597138, 
-149.328680,61.597628, 
-149.328165,61.598281, 
-149.327650,61.598526))
mud_lake = matrix(ncol=2,byrow=TRUE,
c(-149.338464,61.600078, 
-149.337778,61.599506, 
-149.337434,61.598853, 
-149.339323,61.598118, 
-149.341211,61.597465, 
-149.343614,61.596730, 
-149.343614,61.595913, 
-149.343786,61.595505, 
-149.345159,61.594934, 
-149.347047,61.595424, 
-149.348249,61.595750, 
-149.349107,61.596648, 
-149.350652,61.597220, 
-149.351854,61.597220, 
-149.349107,61.598036, 
-149.347219,61.598281, 
-149.344988,61.598281, 
-149.342928,61.599425, 
-149.340696,61.599751, 
-149.339494,61.600078))
cottonwood_creek =
  matrix(ncol=2,byrow=TRUE,
c(-149.343958,61.595750, 
-149.343099,61.595832, 
-149.342413,61.595750, 
-149.341898,61.595424, 
-149.341039,61.595260, 
-149.340181,61.594934, 
-149.338808,61.594852, 
-149.337778,61.594934))
#
#  UTM CONVERSION
utm_convert = function(longlat){
    longlat = as.data.frame(longlat[,1:2])
    names(longlat) = c("X","Y")
    coordinates(longlat) = c("X", "Y")
    sp::proj4string(longlat) = 
      CRS("+proj=longlat +datum=WGS84")
    res = spTransform(longlat, 
      CRS("+proj=utm +zone=5
          ellps=WGS84"))
    res
}
#
cottonwood = utm_convert(cottonwood)@coords
cotton_island = utm_convert(cotton_island)@coords
mud_lake = utm_convert(mud_lake)@coords
cottonwood_creek = 
      utm_convert(cottonwood_creek)@coords
summary(cottonwood)
summary(mud_lake)
x_lim = c(693320, 696120)
y_lim = c(6834320, 6835680)
plot(x=NULL,y=NULL,xlim=x_lim, ylim=y_lim,asp=1)
polygon(cottonwood[,1:2],lwd=2)
polygon(mud_lake[,1:2],lwd=2)
polygon(cotton_island[,1:2],lwd=2)
lines(cottonwood_creek[,1:2],lwd=2)

## ----fill---------------------------------------------------------------------
flipit = function(x){
  n = nrow(x)
  x[(n:1),]
}
x_seq = seq(x_lim[1],x_lim[2],by=20)
y_seq = seq(y_lim[1],y_lim[2],by=20)
grid = as.matrix(expand.grid(x_seq,y_seq))
inside1 = ptinpoly::pip2d(flipit(cottonwood)[,1:2], grid)==1
inside1 = (ptinpoly::pip2d(flipit(cotton_island)[,1:2], grid)== (-1))&inside1
inside2 = ptinpoly::pip2d(flipit(mud_lake)[,1:2], grid)==1
lake_nodes = rbind(grid[inside1,],
                   grid[inside2,])
#
#  Stream
#
cotton_creek_nodes = approx(cottonwood_creek, xout = seq(693990,694289,by=20))
cotton_creek_nodes$x = c(cotton_creek_nodes$x, 694295)
cotton_creek_nodes$y = c(cotton_creek_nodes$y, 6834523)
#
cotton_creek_nodes = 
  cbind(cotton_creek_nodes$x,
        cotton_creek_nodes$y)
lake_nodes = rbind(lake_nodes,
                   cotton_creek_nodes)
#
n_creek = nrow(cotton_creek_nodes)
n_lakes = nrow(lake_nodes)
n_creek
n_lakes

## ----nodes--------------------------------------------------------------------
creek_index = (n_lakes - n_creek+1):n_lakes
temp = RANN::nn2(lake_nodes,
                 lake_nodes, k=5)
hist(temp$nn.dists[temp$nn.dists>0],n=100)
NN = nrow(lake_nodes)
latt_lakes = spam(ncol=NN,nrow=NN,0)
for(i in 1:NN){
  close_nodes = temp$nn.idx[i,2:5]
  close_nodes = close_nodes[temp$nn.dists[i,2:5]<50]
  latt_lakes[i,close_nodes] = 1L
}
  latt_lakes = 
    sign(latt_lakes+t(latt_lakes))
  latt_lakes = spam::cleanup(latt_lakes)

## ----transition---------------------------------------------------------------
isSymmetric(latt_lakes)
rowSUMS = rowSums(latt_lakes)
T = makeTranMatrix(latt_lakes, M=0.5)

## ----analysis1----------------------------------------------------------------
locs = structure(c(695920, 694600, 693720, 693960, 694880, 694195, 695560, 695760, 694000, 695000, 694640, 694600, 6835160, 6834440, 6834760, 6834920, 6834840, 6834511, 6834920, 6834800, 6834960, 6834600, 6835000, 6834880), .Dim = c(12L, 2L))
Z = c(56, 26, 12, 15, 34, 21, 47, 51, 16, 35, 30, 29)
plot(lake_nodes, xlim=x_lim, 
     ylim=y_lim, pch=19, cex=0.2,
     xlab="Easting",ylab="Northing",asp=1)
points(cotton_creek_nodes, cex=0.2)
points(locs, col=heat_hcl(7)[(Z/10)+1], cex=1, pch=19,
       xlab="Easting",ylab="Northing")

## ----analysis2----------------------------------------------------------------
out = crossvalNparSmoother(T, nodelocs=lake_nodes, locs=locs, Z=Z, k_max = 60)
plot(out$press,lwd=2,type="l")
locs = cbind(locs,rep(0,12))
lake_nodes = cbind(lake_nodes,
                   rep(0,n_lakes))
map = nparSmoother(T,          
    nodelocs=
          lake_nodes, 
          Z=Z, locs=locs, 
          k = out$k)
vals = map[,4]
color = heat_hcl(7)[(vals/10)+1]
plot(map[,1],map[,2],col=color,pch=19,cex=0.8,
     xlab="Easting",ylab="Northing")
polygon(cottonwood[,1:2],lwd=4)
polygon(mud_lake[,1:2],lwd=4)
polygon(cotton_island[,1:2],lwd=4)
lines(cottonwood_creek[,1:2],lwd=1)
#

## ----last,eval=TRUE,echo=FALSE------------------------------------------------
pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/CottonLocs.pdf", height=4)
par(mfrow=c(1,2))
plot(lake_nodes,xlim=x_lim, ylim=y_lim,pch=19,cex=0.2,
     xlab="Easting",ylab="Northing",asp=1)
points(cotton_creek_nodes,cex=0.2)
points(locs, col=heat_hcl(7)[(Z/10)+1], cex=1, pch=19)
#
#
plot(map[,1],map[,2],col=color,pch=19,cex=0.8,
     xlab="Easting",ylab="Northing",asp=1)
polygon(cottonwood[,1:2],lwd=4)
polygon(mud_lake[,1:2],lwd=4)
polygon(cotton_island[,1:2],lwd=4)
lines(cottonwood_creek[,1:2],lwd=1)
dev.off()

