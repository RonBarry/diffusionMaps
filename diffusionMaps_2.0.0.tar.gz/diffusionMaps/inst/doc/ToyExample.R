## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(spam)
library(diffusionMaps)
library(colorspace)

## ----simple,fig.height=4------------------------------------------------------
nodelocs = matrix(ncol=3,byrow=TRUE,
c(1,1,0,
  2,1,0,
  1,2,0,
  2,2,0,
  3,2,0,
  4,2,0,
  5,2,0,
  6,2,0,
  5,1,0,
  6,1,0))
lakeShape_x = c(1.004, 0.662, 0.693, 0.615, 
                0.482, 0.852, 1.345, 
  1.862, 2.628, 
3.143, 3.398, 3.95, 4.393, 5.129, 5.762, 6.69, 6.599, 6.622, 
6.779, 6.629, 6.247, 5.522, 4.979, 4.516, 4.406, 4.036, 3.523, 
3.115, 2.943, 2.801, 2.87, 2.445, 1.741, 0.943, 1.004)
lakeShape_y = c(0.789, 0.982, 1.254, 1.721, 2.517, 2.655, 2.632, 2.714, 2.678, 
2.657, 2.594, 2.752, 2.667, 2.691, 2.694, 2.633, 1.767, 1.444, 
1.225, 1.05, 0.845, 0.835, 0.741, 0.938, 1.437, 1.639, 1.659, 
1.716, 1.532, 1.164, 0.969, 0.868, 0.755, 0.808, 0.789)
nodelocs
plot(lakeShape_x,lakeShape_y,type="l",xlab="x",ylab="y")
points(6,1.1,pch=4,cex=2,lwd=2)
plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),
     pch=19,xlab="x",ylab="y")
lines(lakeShape_x,lakeShape_y)
text(nodelocs[,1:2]+0.2,labels=1:10)
#f = "/Users/ronaldbarry/Desktop/diffusionMap paper/first.pdf"
#pdf(file=f)
#
#

plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),pch=19,
     asp=1,xlab="x",ylab="y")
text(nodelocs[,1:2]+0.2,labels=1:10)
lines(lakeShape_x,lakeShape_y)
#lake = "/Users/ronaldbarry/Desktop/diffusionMap paper/lake.pdf"
#pdf(file=lake)
plot(lakeShape_x,lakeShape_y,type="l",
     asp=1,xlab="x",ylab="y")
points(6,1.1,pch=4,cex=2,lwd=2)

## ----adj----------------------------------------------------------------------
latt = spam(nrow=10,ncol=10,0)
latt[1,3] = latt[1,2] = latt[2,4] = latt[3,4] = 1
latt[4,5] = latt[5,6] = latt[6,7] = latt[7,8] = 1
latt[7,9] = latt[8,10] = latt[9,10] = 1
latt = latt + t(latt)
as.matrix(latt)

## ----iso----------------------------------------------------------------------
T = latt*(1/6)
cs = colSums(T)
diag(T) = 1-cs
round(as.matrix(T),2)
out = plotMesh(latt,nodelocs)
plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),
     pch=19,xlab="x",ylab="y")
lines(lakeShape_x,lakeShape_y,type="l")
for(i in 1:23){segments(x0=out$start[i,1],
                        y0=out$start[i,2],
                        x1=out$finish[i,1],
                        y1=out$finish[i,2])}
#f = "/Users/ronaldbarry/Desktop/diffusionMap paper/second.pdf"
#pdf(file=f)
plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),pch=19,
     xlab="x",ylab="y")
lines(lakeShape_x,lakeShape_y,type="l")
for(i in 1:23){segments(x0=out$start[i,1],
                        y0=out$start[i,2],
                        x1=out$finish[i,1],
                        y1=out$finish[i,2])}

## ----analysis-----------------------------------------------------------------
locs = matrix(ncol=3,nrow=1,c(6,1.1,0))
out = nparDensity(T, nodelocs, locs, k = 5)
out
colors = colorspace::heat_hcl(length(out[,4]))[rank(out[,4])]
plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),pch=19,
     col=colors,xlab="x",ylab="y",cex=3)
lines(lakeShape_x,lakeShape_y,type="l")
text(nodelocs[,1:2]+0.2,labels=round(out[,"prob"],4),cex=1)
#f = "/Users/ronaldbarry/Desktop/diffusionMap paper/third.pdf"
#pdf(file=f)
plot(nodelocs[,1:2],xlim=c(0,8),ylim=c(0,3),pch=19,
     col=colors,cex=3,xlab="x",ylab="y")
lines(lakeShape_x,lakeShape_y,type="l")
text(nodelocs[,1:2]+0.2,labels=round(out[,"prob"],4),cex=1)

