## ----setup, message = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(spam)
library(RANN)
library(colorspace)
library(sqldf)
library(mgcv)

## ----surfaceGrid,fig.height=8,fig.width=5-------------------------------------
#  Place a rectangular grid on the map
lat_spacing = 0.05
lat_sel = seq(41.62,46.03,by=lat_spacing)
long_sel = seq(-88,-84.5,by=1.5*lat_spacing)
Mich_grid = expand.grid(long_sel, lat_sel)
colnames(Mich_grid)=c("x","y")
Mich_grid = as.matrix(Mich_grid)
#  Get the polygonal boundary of the lake
data(Mich_poly)
colnames(Mich_poly)=c("x","y")
Mich_poly = as.matrix(Mich_poly)
#  Keep only locations within the polygonal boundary
inside = mgcv::in.out(bnd=Mich_poly,Mich_grid)
Mich_grid = Mich_grid[inside,]

## ----lakeMichDepth, eval=FALSE------------------------------------------------
#  #
#  #  The depth file is huge, around 9 million values, so to save
#  #  time I'll start with an SQL (SQLite) select statement to
#  #  filter the file before reading it into R and especially before
#  #  subjecting it to the nearest neighbor function.
#  #
#  f = "/Users/ronaldbarry/Desktop/Inactive Research Folders/Three-Dee/LakeMichDepth.txt"
#  sql_statement = "select long,lat,depth,(lat - 41.62) as templat, (long + 88) as templong from file where (abs(templat - 0.05*round(templat/0.05,0)) < 0.01)and(abs(templong - 0.075*round(templong/0.075,0)) < 0.01)"
#  Mich_depth = sqldf::read.csv.sql(file=f,sql = sql_statement,header=TRUE,sep=' ')[,1:3]
#  #
#  #  Each grid point gets the depth from the closest depth measurement.
#  #
#  near_nbrs = RANN::nn2(data=Mich_depth[,1:2], query=Mich_grid,k=1)
#  Mich_depth = Mich_depth[near_nbrs$nn.idx,]
#  #  There are a couple of problematic grid points that aren't close
#  #  to any of the filtered depth measurements.  I'll delete those.
#  #  NOTE:  I'm not deleting data, just a grid location.
#  #
#  Mich_depth = Mich_depth[near_nbrs$nn.dist<0.04,]
#  Mich_grid = Mich_grid[near_nbrs$nn.dist<0.04,]
#  Grid_depth = as.data.frame(cbind(Mich_grid,depth=Mich_depth$depth))
#  plot(Mich_grid,asp=1.5)
#  lines(Mich_poly,col=3,lwd=2)
#  #  I'll put a node at the surface, then every ten meters down.
#  number_vertical_nodes = trunc(Grid_depth$depth/10) + 1
#  Lake_Michigan_nodelocs = matrix(nrow=sum(number_vertical_nodes), ncol=3, NA)
#  Lake_Michigan_nodelocs[,1] = rep(Grid_depth[,1],times=number_vertical_nodes)
#  Lake_Michigan_nodelocs[,2] = rep(Grid_depth[,2],times=number_vertical_nodes)
#  Lake_Michigan_nodelocs[,3] = unlist(lapply(number_vertical_nodes,
#                            FUN=function(x){0.05*(1:x)}))

## ----michdat------------------------------------------------------------------
data(Lake_Michigan_nodelocs)

## ----lattice------------------------------------------------------------------
temp = as.matrix(dist(Lake_Michigan_nodelocs))
dim(temp)
adj_matrix = (((temp<0.076)&(temp>0.074))|((temp<0.051)&(temp>0.049)))+0.0
latt_Mich = spam::as.spam(adj_matrix)
dim(latt_Mich)
isSymmetric(latt_Mich)
table(rowSums(latt_Mich))

## ----datNOX-------------------------------------------------------------------
data(Mich_NOX)
plot(Mich_grid,asp=1.5,cex=0.1)
points(Mich_NOX$longitude,Mich_NOX$latitude, col='red')
NOX_locations = cbind(Mich_NOX$longitude, Mich_NOX$latitude, Mich_NOX$sample.depth/200)

## ----LakeMichSmooth-----------------------------------------------------------
T_Mich = makeTranMatrix(latt=latt_Mich, M=0.5)
Lake_Mich_map = nparSmoother(T=T_Mich, 
                             nodelocs=Lake_Michigan_nodelocs, 
                             Z=Mich_NOX$totalOxiN, 
                             locs = NOX_locations, k = 130)
node_color = 
  colorspace::heat_hcl(11)[round(100*(Lake_Mich_map[,4]-0.27))+1]
#hist(Lake_Mich_map[,4])
#hist(Mich_NOX$totalOxiN)
plot(Mich_NOX$latitude, 
     Mich_NOX$sample.depth, col=node_color,
     pch=19)
xlims = range(Mich_poly[,1])
ylims = range(Mich_poly[,2])
#
Lake_Mich_map = data.frame(Lake_Mich_map, node_color,
                           stringsAsFactors=FALSE)
depths = Lake_Mich_map[,3]
mich_slice1 = Lake_Mich_map[depths==0.05,c(1,2,6)]
mich_slice2 = Lake_Mich_map[depths==0.25,c(1,2,6)]
mich_slice3 = Lake_Mich_map[depths==0.5,c(1,2,6)]
mich_slice4  = Lake_Mich_map[depths==0.75,c(1,2,6)]
#
point_size = 2.5
#
plot(mich_slice1[,1:2],col=mich_slice1[,3],
       cex=point_size, pch=15, xlim=xlims, ylim=ylims)
lines(Mich_poly, lwd=4, asp=1)
title("Surface")

## ----last,eval=TRUE,echo=FALSE------------------------------------------------
pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/LakeMichAll.pdf")
layout(matrix(nrow=3,ncol=2,byrow=TRUE,
              c(1,2,3,4,5,5)),
       heights=c(1,0.9,0.5))
plot(mich_slice1[,1:2],col=mich_slice1[,3],
       cex=point_size, pch=15, xlim=xlims, ylim=ylims)
lines(Mich_poly, lwd=4, asp=1)
title("Surface")
#
plot(mich_slice2[,1:2],col=mich_slice2[,3],
       cex=point_size, pch=15, xlim=xlims, ylim=ylims)
lines(Mich_poly, lwd=4, asp=1)
title("50 meters")
#
#
plot(mich_slice3[,1:2],col=mich_slice3[,3],
       cex=point_size, pch=15, xlim=xlims, ylim=ylims)
lines(Mich_poly, lwd=4, asp=1)
title("100 meters")
#
plot(mich_slice4[,1:2],col=mich_slice4[,3],
       cex=point_size, pch=15, xlim=xlims, ylim=ylims)
lines(Mich_poly, lwd=4, asp=1)
title("150 meters")
plot.new()
vals = seq(0.27,0.34,length=8)
legend("right", legend=vals, col=colorspace::heat_hcl(9)[round(100*(vals-0.27))+1],
       horiz=TRUE,pch=19, cex=1.83)
#dev.off()
#
#

## ----plots,fig.height=8,echo=FALSE,eval=TRUE----------------------------------
lats = unique(Lake_Mich_map[,2])
latitude2 = Lake_Mich_map[,2]
lat_slices = as.list(1:12)
pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/LakeMichLatSlices.pdf")
#par(mfrow=c(4,4), mar = c(2, 4, 4, 2) + 0.1, oma=c(0,0,6,0))
layout(matrix(nrow=4,ncol=4,byrow=TRUE,c(1,2,3,4,5,6,7,8,9,10,11,12,13,13,13,13)))
for(i in 1:12){
  lat_slices[[i]] = Lake_Mich_map[latitude2==lats[7*i],c(1,3,6)]
  plot(lat_slices[[i]][,1],200*lat_slices[[i]][,2],
       col=lat_slices[[i]][,3],
       cex=point_size, pch=15, xlim=xlims, ylim = c(260,0),
       xlab="longitude", ylab="depth")
  title(paste("Latitude =",lats[7*i],"\n"))
}
plot.new()
legend("bottom", legend=vals, col=colorspace::heat_hcl(9)[round(100*(vals-0.27))+1],
       horiz=TRUE,pch=19, cex=1.83)
#dev.off()

