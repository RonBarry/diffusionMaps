## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(Directional)

## ----singlesphere-------------------------------------------------------------
radius = 5
N = 200000
output = sphereNodes(N=N,radius=radius)
sphere_nodes = output$sphere_nodes
longlat = output$longlat
angles = output$angles
#
#  sphere_nodes has the (x,y,z) coordinates of nodes
#  angles has two angles associated with each node
#  longlat has the latitude and longitude assoc. with each node
#
outout = RANN::nn2(data = sphere_nodes, 
                   query = sphere_nodes, k = 5)
#
NN = nrow(longlat)
latt_sphere = spam(ncol=NN,nrow=NN,0)
for(i in 1:NN){
  close_nodes = outout$nn.idx[i,2:5]
  close_nodes = close_nodes[outout$nn.dists[i,2:5]<0.3]
  latt_sphere[i,close_nodes] = 1L
  latt_sphere = sign(latt_sphere+t(latt_sphere))
  latt_sphere = spam::cleanup(latt_sphere)
}

## ----pictlat------------------------------------------------------------------
dim(latt_sphere)
scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],z=sphere_nodes[,3],cex=0.1,col=1)

## ----density------------------------------------------------------------------
mu_sim1 = c(5,-3,4)
mu_sim1 = mu_sim1/sqrt(sum(mu_sim1^2))
mu_sim2 = c(2,-5,2)
mu_sim2 = mu_sim2/sqrt(sum(mu_sim2^2))
part1 = dfish(sphere_nodes, mu_sim1, k=80)
part2 = dfish(sphere_nodes, mu_sim2, k=80)
true_density = (part1+part2)/2
true_density=true_density/sum(true_density)
#
#
T_1_sphere = makeTranMatrix(latt_sphere,M=0.5)

## ----sims---------------------------------------------------------------------
simul_points = function(n){
  n1 = rbinom(1,size=n,prob=0.5)
  point_process1 = rvmf(n1,mu_sim1,k=80)*5
  point_process2 = rvmf(n-n1,mu_sim2,k=80)*5
  point_process = rbind(point_process1, point_process2)
  point_process
}

## ----moresims-----------------------------------------------------------------
find_density = function(T_1_sphere, sphere_nodes, point_process){
  crossval_info = crossvalNparDensity(T=T_1_sphere, 
                    nodelocs = sphere_nodes, 
                    locs = point_process, k_max = 100)
  #
  out_1 = nparDensity(T=T_1_sphere, nodelocs = sphere_nodes, locs = point_process, k = crossval_info$k)
  #
  est_density = out_1[,4]
  est_density = est_density/sum(est_density)
  list(est_density = est_density,
       k = crossval_info$k)
}

## ----MISE---------------------------------------------------------------------
sim_single_n = function(n, sim_reps){
  vector_ISE = rep(NA,sim_reps)
  vector_k = rep(NA,sim_reps)
  for(m in 1:sim_reps){
    point_process = simul_points(n)
    temp = find_density(T_1_sphere=T_1_sphere, 
                          sphere_nodes=sphere_nodes, 
                          point_process=point_process)
    est_density = temp$est_density
    vector_ISE[m] = sum((est_density-true_density)^2)*8005/(4*pi)
    vector_k[m] = temp$k
  }
list(vector_ISE=vector_ISE, k = vector_k)
}

## ----simulation---------------------------------------------------------------
sim_reps = 5
start = Sys.time()
temp10 = sim_single_n(n=10, sim_reps=sim_reps)
time10 = Sys.time() - start
#
start = Sys.time()
temp40 = sim_single_n(n=40, sim_reps=sim_reps)
time40 = Sys.time() - start
#
start = Sys.time()
temp160 = sim_single_n(n=160, sim_reps=sim_reps)
time160 = Sys.time() - start
#
start = Sys.time()
temp640 = sim_single_n(n=640, sim_reps=sim_reps)
time640 = Sys.time() - start
#
start = Sys.time()
temp2560 = sim_single_n(n=2560, sim_reps=sim_reps)
time2560 = Sys.time() - start
#
#
mean(temp10$vector_ISE)
mean(temp40$vector_ISE)
mean(temp160$vector_ISE)
mean(temp640$vector_ISE)
mean(temp2560$vector_ISE)
#
mean(temp10$k)
mean(temp40$k)
mean(temp160$k)
mean(temp640$k)
mean(temp2560$k)
#
time10
time40
time160
time640
time2560

