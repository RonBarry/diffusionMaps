#' Diffusion-based non-parametric density estimation.
#'
#' @param T Sparse transition matrix.
#' @param nodelocs 3-column matrix of node locations.
#' @param locs 3-column matrix of locations of data.
#' @param k Integer number of steps in the diffusion.
#'
#' @import spam
#' @import RANN
#' @export
#'
nparDensity = function(T, nodelocs, locs, k = 10)
{
  n_nodes <- nrow(nodelocs)
  n_observ = nrow(locs)
  #
  temp = RANN::nn2(data = nodelocs, query = locs, k = 1)
  which_nodes <- as.vector(temp$nn.idx)
  p0 = tabulate(which_nodes ,nbins = n_nodes)/n_observ
  #
  #
  pk <- as.vector(p0)
  for (i in 1:k) {
    pk = T%*%pk
  }
  #
  out = cbind(nodelocs, pk)
  if(ncol(nodelocs)==2){
    colnames(out) = c("x","y","prob")
  }else if(ncol(nodelocs)==3){
    colnames(out) = c("x","y","z","prob")
  }else{
    colnames(out) = c("x","y","z","t","prob")
  }
  out
}
