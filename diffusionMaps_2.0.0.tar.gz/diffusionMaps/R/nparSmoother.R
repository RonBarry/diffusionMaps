#' Diffusion-based non-parametric regression smoother.
#'
#' nparSmoother takes a transition matrix, a matrix
#' of node locations, a matrix of data locations, a set of
#' data values and a number of steps to yield a non-parametric
#' regression with values on the nodes.
#'
#' If n_nodes is the number of nodes and n_observ is the
#' number of observations, the transtion matrix is a sparse
#' n_nodes by n_nodes matrix that shows the flow rates between
#' neighbors.  nodelocs are locations in d dimensions of the nodes,
#' while locs are locations in d dimensions of the data.  This version
#' of the function only allows d=3 or d=4 (three or four dimensional
#' data).
#'
#' @param T A spam object, a probability transition matrix.
#' @param nodelocs A matrix of node locations
#' @param Z A vector of data.
#' @param locs A matrix of data loations.
#' @param k A number that determines the number of steps.
#'
#' @return A matrix including the map.
#' @import spam
#' @export
#
nparSmoother = function(T, nodelocs, Z, locs, k = 10)
{
  n_nodes <- nrow(nodelocs)
  n_observ = nrow(locs)
  #
  temp = RANN::nn2(data = nodelocs, query = locs, k = 1)
  which_nodes <- as.vector(temp$nn.idx)
  p0 = tabulate(which_nodes ,nbins = n_nodes)/n_observ
  sums <- function(x) {
    sum(Z[which_nodes == x])
  }
  Z0 = as.numeric(lapply(1:n_nodes, FUN=sums))/n_observ
  #
  #
  pk <- p0
  for (i in 1:k) {
    pk = T%*%pk
  }
  zk <- Z0
  for (i in 1:k) {
    zk = T%*%zk
  }
  est = zk/pk
  outside_support = is.nan(est)|is.na(est)
  est[outside_support] = mean(Z)
  #
  out = cbind(nodelocs, est, outside_support)
  if(ncol(nodelocs)==3){
    colnames(out) = c("x","y","z","value","outside support")
    }else{
    colnames(out) = c("x","y","z","t","value","outside support")
       }
  out
}
