#' Lake Michigan Node Locations.
#'
#' This is a set of nodes that fills Lake Michigan,
#' with longitude, latitude and depth.
#'
#' @format A data frame with 1538 rows and 2 variables:
#' \describe{
#'   \item{longitude}{}
#'   \item{latitude}{}
#'   \item{depth}{}
#' }
"Lake_Michigan_nodelocs"
