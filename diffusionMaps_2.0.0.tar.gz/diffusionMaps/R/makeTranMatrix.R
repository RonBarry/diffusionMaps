#' Build a symmetric, stationary transition matrix.
#'
#' This functions creates the simplest diffusion transition matrix,
#' such as was used in the R package \code{latticeDensity}.  In this
#' model the neighbor relationship (as found in \code{latt}) is
#' symmetric with equal flow rates in all directions, such as
#' would be seen with diffusion in an isotropic medium.
#'
#' The transition matrix T uses the same transition
#' probability for each movement to and from neighbors and assumes that
#' if node A is a neighbor to node B, that the reverse is also true.
#' To be exact,
#' the rate is govered by the parameter M, which is the maximum
#' probability or movement (depending on whether you are at a
#' boundary or not).
#'
#' If R_max is the largest number of neighbors of any node, and
#' node i has n_i neighbors, the probability of movement from
#' node i to any neighbor will be M/R_max.  This means that the
#' probability of movement is M*n_i/R_max, which will be M for
#' at least one node, while the probability of not moving on each
#' step will be 1 - M*n_i/R_max.
#'
#'
#' @param latt A spam object, symmetric, with 1 for neighbors, 0 otherwise.
#' @param M A number, the maximum probability of not moving.
#' @return T A sparse (spam object) transition probability matrix.
#'
#'
#' @import spam
#'
#' @family Transition matrix functions
#'
#' @export
#' @examples
#' latt = spam(nrow=5,ncol=5,0)
#' for(i in 1:4)
#' {
#'   latt[i,i+1] = 1
#'   latt[i+1,i] = 1
#' }
#' latt
#' T = makeTranMatrix(latt, M=0.5)
#' T
#'
makeTranMatrix = function(latt, M=0.5)
{
  if(!isSymmetric(latt))stop("makeTranMatrix works with symmetric neighbors, only.")
  rowTotals <- apply.spam(latt,MARGIN=1,sum)
  diags <- 1 - M*(rowTotals/max(rowTotals))
  T = diags%d+%(M*latt/max(rowTotals))
  T
}
