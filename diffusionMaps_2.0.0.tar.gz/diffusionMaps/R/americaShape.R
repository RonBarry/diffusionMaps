#' America shape polygon.
#'
#' This is a shapefile (polygon) of the outline of the
#' Americas in longitude and latitude.
#'
#' @format A data frame with 124 rows and 2 variables:
#' \describe{
#'   \item{latitude}{}
#'   \item{longitude}{}
#' }
"americaShape"
