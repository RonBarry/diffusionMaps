#' Antartica polygon.
#'
#' This is a shapefile (polygon) of the outline of Antarctica,
#' in longitude and latitude.
#'
#' @format A data frame with 48 rows and 2 variables:
#' \describe{
#'   \item{latitude}{}
#'   \item{longitude}{}
#' }
"antarcticaShape"
