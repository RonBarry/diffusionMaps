## ----setup, message = FALSE----------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(spam)
library(RANN)
library(geometry)
library(plot3Drgl)

## ----part1---------------------------------------------------------------
n = 30      # nodes per 24 hour period (around cylinder)
m = 450     # nodes axially along cylinder
#
ang = seq(0,2*pi,l=(n+1))[1:n]
temp = expand.grid(ang,1:m)
D = sqrt(sin(2*pi/n)^2 + (1-cos(2*pi/n))^2)
#
#  Divison by D makes the distance between neighbors equal 1.
#
shape = cbind(sin(temp[,1])/D,cos(temp[,1])/D,temp[,2])
latt_cylinder = spam::nearest.dist(x=shape, delta=1.1, upper=NULL)
latt_cylinder = round(latt_cylinder)
latt_cylinder = spam::cleanup(latt_cylinder)
#  Handy information about the sparse neighbor matrix latt_cylinder
isSymmetric(latt_cylinder)
any(diag(latt_cylinder) != 0)

## ----part2---------------------------------------------------------------
data(intensive_care,package="diffusionMaps")
date_care = paste(intensive_care$year,intensive_care$month,
                  intensive_care$day,sep="-")
date_care = paste0(19,date_care)
days_since_1963Jan1 = as.numeric(difftime(date_care,"1963-1-1",units="days"))
decimal_time = intensive_care$hour + intensive_care$mins/60
head(data.frame(days_since_1963Jan1, decimal_time))
time_angle = decimal_time*2*pi/24
data_locs_cylinder = cbind(sin(time_angle)/D,cos(time_angle)/D, days_since_1963Jan1 + decimal_time/24)

## ----part3,fig.height=4--------------------------------------------------
T_cyl = makeTranMatrix(latt = latt_cylinder)
out = crossvalNparDensity(T=T_cyl, nodelocs=shape, 
                          locs = data_locs_cylinder, k_max = 50)
plot(out$ucv,lwd=2,type="l")
cyl_out = nparDensity(T=T_cyl, nodelocs = shape, 
                      locs = data_locs_cylinder, k = out$k)
node_probabilites = cyl_out[,4]
summary(node_probabilites)

## ----crossval,eval=FALSE-------------------------------------------------
#  for(axial in c(0.05,0.2,0.3,0.4))
#  {
#  T_cyl = simple_anisoT(latt = latt_cylinder,
#                          nodelocs = shape,
#                          axial_move = axial,
#                          nonaxial_move = 0.05)
#  cross = crossvalNparDensity(T = T_cyl,
#                      nodelocs = shape,
#                      locs = data_locs_cylinder,
#                      k_max = 10000)
#  cat("optimal steps=", cross$k, " UCV=",cross$ucv[cross$k]," axial prob =",axial,"\n")
#  }

## ----anisotropy,fig.height=4---------------------------------------------
#
T_cyl = simple_anisoT(latt = latt_cylinder, 
                        nodelocs = shape, 
                        axial_move = 0.4, 
                        nonaxial_move = 0.05)
cyl_out = nparDensity(T=T_cyl, nodelocs = shape, 
                      locs = data_locs_cylinder, 
                      k = 4000)
summary(cyl_out)
node_probabilites = cyl_out[,4]

## ----newplot-------------------------------------------------------------
M  <- mesh(ang, 1:m)
u  <- M$x
v  <- M$y
# x, y and z grids
x  <-  sin(u)/D
y  <- cos(u)/D
z  <- v

probmat=matrix(node_probabilites,nrow=n,ncol=m,byrow=F)
surf3D(x, y, z, colvar = probmat, col=heat.colors(1000), colkey = FALSE, shade = 0.1, 
       theta = 45, phi=20, box = TRUE, plot = TRUE, expand=2, bty="b2",zlab="days")
#pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/AnisoCylinder.pdf")
surf3D(x, y, z, colvar = probmat, col=heat.colors(1000), colkey = FALSE, shade = 0.1, 
       theta = 45, phi=20, box = TRUE, plot = TRUE, expand=2, bty="b2",zlab="days")
#dev.off()

