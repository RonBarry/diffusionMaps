## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(spam)
library(plot3D)
library(colorspace)
library(Directional)
library(plot3Drgl)

## ----singlesphere--------------------------------------------------------
radius = 5
N = 200000
output = sphereNodes(N=N,radius=radius)
sphere_nodes = output$sphere_nodes
longlat = output$longlat
angles = output$angles
#
#  sphere_nodes has the (x,y,z) coordinates of nodes
#  angles has two angles associated with each node
#  longlat has the latitude and longitude assoc. with each node
#
outout = RANN::nn2(data = sphere_nodes, 
                   query = sphere_nodes, k = 5)
#
NN = nrow(longlat)
latt_sphere = spam(ncol=NN,nrow=NN,0)
for(i in 1:NN){
  close_nodes = outout$nn.idx[i,2:5]
  close_nodes = close_nodes[outout$nn.dists[i,2:5]<0.3]
  latt_sphere[i,close_nodes] = 1L
  latt_sphere = sign(latt_sphere+t(latt_sphere))
  latt_sphere = spam::cleanup(latt_sphere)
}

## ----pictlat-------------------------------------------------------------
#temp_mesh = plotMesh(latt_sphere, sphere_nodes)
#start = temp_mesh$start
#finish = temp_mesh$finish
#start_finish_x = cbind(start[,1],finish[,1])
#start_finish_y = cbind(start[,2],finish[,2])
#start_finish_z = cbind(start[,3],finish[,3])
#
scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],z=sphere_nodes[,3],cex=0.1,col=1)

## ----sim-----------------------------------------------------------------
set.seed(12347)
mu_sim1 = c(5,-3,4)
mu_sim1 = mu_sim1/sqrt(sum(mu_sim1^2))
mu_sim2 = c(2,-5,2)
mu_sim2 = mu_sim2/sqrt(sum(mu_sim2^2))
#
n1 = rbinom(1,size=50,prob=0.5)
point_process1 = rvmf(n1,mu_sim1,k=80)*5
point_process2 = rvmf(50-n1,mu_sim2,k=80)*5
point_process = rbind(point_process1, point_process2)
#
T_1_sphere = makeTranMatrix(latt_sphere,M=0.5)
crossval_info = crossvalNparDensity(T=T_1_sphere, 
                    nodelocs = sphere_nodes, 
                    locs = point_process, k_max = 100)
crossval_info$k
#
out_1 = nparDensity(T=T_1_sphere, nodelocs = sphere_nodes, locs = point_process, k = crossval_info$k)
#
probs_out = out_1[,4]
color_out = 1 + round(log(probs_out*3 + 1e-12)+12)
scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],z=sphere_nodes[,3],colvar=color_out,colkey=FALSE,col=terrain.colors(100))
#
points3D(x=point_process[,1]*1.1,y=point_process[,2]*1.1,z=point_process[,3]*1.1,col="black",add=TRUE, pch=4)

## ----fish----------------------------------------------------------------
fish1 = dfish(sphere_nodes, mu_sim1, k=80)
fish2 = dfish(sphere_nodes, mu_sim2, k=80)
fish = (fish1+fish2)/2
color_out2 = 1 + round(log(fish*3 + 1e-12)+12)

## ----view----------------------------------------------------------------
par(mfrow=c(1,2))
scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],
          z=sphere_nodes[,3],
          colvar=color_out2,col=heat.colors(100), 
          colkey =FALSE)
scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],
          z=sphere_nodes[,3],colvar=color_out, 
          colkey=list(length=0.5), col=heat.colors(100))
#
points3D(x=point_process[,1]*1.1,y=point_process[,2]*1.1,
         z=point_process[,3]*1.1,col="black",
         add=TRUE, pch=4)

## ----outpdf,eval=FALSE---------------------------------------------------
#  pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/SphereSimul.pdf", height=4)
#  par(mfrow=c(1,2))
#  scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],
#            z=sphere_nodes[,3],
#            colvar=color_out2,col=heat.colors(100),
#            colkey =FALSE)
#  scatter3D(x=sphere_nodes[,1],y=sphere_nodes[,2],
#            z=sphere_nodes[,3],colvar=color_out,
#            colkey=list(length=0.5), col=heat.colors(100))
#  #
#  points3D(x=point_process[,1]*1.1,y=point_process[,2]*1.1,
#           z=point_process[,3]*1.1,col="black",
#           add=TRUE, pch=4)
#  dev.off()

## ----fisher--------------------------------------------------------------
dfish

