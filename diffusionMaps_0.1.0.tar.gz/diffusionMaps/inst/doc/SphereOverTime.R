## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(spam)
library(plot3D)
library(colorspace)
library(Directional)
library(plot3Drgl)

## ----singlesphere--------------------------------------------------------
radius = 5
N = 200000
output = sphereNodes(N=N,radius=radius)
sphere_nodes = output$sphere_nodes
longlat = output$longlat
angles = output$angles
#
#  sphere_nodes has the (x,y,z) coordinates of nodes
#  angles has two angles associated with each node
#  longlat has the latitude and longitude assoc. with each node
#
outout = RANN::nn2(data = sphere_nodes, 
                   query = sphere_nodes, k = 5)
#
NN = nrow(longlat)
latt_sphere = spam(ncol=NN,nrow=NN,0)
for(i in 1:NN){
  close_nodes = outout$nn.idx[i,2:5]
  close_nodes = close_nodes[outout$nn.dists[i,2:5]<0.3]
  latt_sphere[i,close_nodes] = 1L
  latt_sphere = sign(latt_sphere+t(latt_sphere))
  latt_sphere = spam::cleanup(latt_sphere)
}

## ----examine,fig.height=8,fig.width=8------------------------------------
dim(sphere_nodes)
class(sphere_nodes)
dim(latt_sphere)
class(latt_sphere)
hist(outout$nn.dists,n=100)

## ----tripleNodes,fig.height=3--------------------------------------------
row_num = nrow(sphere_nodes)
sphere_nodes3 = rbind(sphere_nodes,sphere_nodes,sphere_nodes)
sphere_nodes3 = cbind(sphere_nodes3,rep(c(0,0.2,0.4),each=row_num))

## ----tripleLatt----------------------------------------------------------
ident = spam::diag.spam(x=1,nrow=NN,ncol=NN)
zerolatt = spam(x=0,nrow=NN,ncol=NN)
latt_3_spheres = rbind(cbind(latt_sphere,ident,zerolatt),
                      cbind(ident,latt_sphere,ident),
                      cbind(zerolatt,ident,latt_sphere))

## ----onept---------------------------------------------------------------
makeAnisoT_3spheres = function(theta,latt_sphere,ident,zerolatt){
  # theta <= 1/10
  out = rbind(cbind((1/10)*latt_sphere,theta*ident,zerolatt),
            cbind(theta*ident,(1/10)*latt_sphere,theta*ident),
            cbind(zerolatt,theta*ident,(1/10)*latt_sphere))
  diag(out) = 1 - colSums(out)
  out = as.spam(out)
  out = spam::cleanup(out)
  out
}
#
#
#
T_3_spheres = makeAnisoT_3spheres(theta=0.00005,latt_sphere,ident,zerolatt)

## ----fisher,fig.height=3-------------------------------------------------
#
#  Simulate from Fisher distribution
#
set.seed(12345)
mu1 = c(5,-3,4)
point_process1 = rvmf(20,mu1/sqrt(sum(mu1^2)),k=45)
point_process1 = point_process1*5
#
mu2 = c(0.5,0.5,5)
point_process2 = rvmf(20,mu2/sqrt(sum(mu2^2)),k=45)
point_process2 = point_process2*5
#
mu3 = c(2.5,-1.5,4.5)
point_process3 = rvmf(10,mu3/sqrt(sum(mu3^2)),k=10)
point_process3 = point_process3*5
process = rbind(point_process1,point_process2,point_process3)
process = cbind(process,c(rep(0,20),rep(0.4,20),rep(0.2,10)))
#
#
out = nparDensity(T=T_3_spheres, nodelocs = sphere_nodes3, locs = process, k = 15)
probs_out = out[,5]
t = sphere_nodes3[,4]
color_out = round(log(probs_out+1e-12) + 29)
summary(color_out)
N_rows = nrow(sphere_nodes3)
#
#
#
#
par(mfrow=c(1,3))
scatter3D(x=sphere_nodes3[t==0,1],y=sphere_nodes3[t==0,2],z=sphere_nodes3[t==0,3],colvar=color_out[t==0],colkey=FALSE, col=heat.colors(24))
#
points3D(x=point_process1[,1]*1.1,y=point_process1[,2]*1.1,z=point_process1[,3]*1.1,col="black", add=TRUE, pch=4)
#
scatter3D(x=sphere_nodes3[t==0.2,1],y=sphere_nodes3[t==0.2,2],z=sphere_nodes3[t==0.2,3],colvar=color_out[t==0.2],colkey=FALSE, col=heat.colors(24))
#
points3D(x=point_process3[,1]*1.1,y=point_process3[,2]*1.1,z=point_process3[,3]*1.1,col="black",add=TRUE, pch=4)
#
scatter3D(x=sphere_nodes3[t==0.4,1],y=sphere_nodes3[t==0.4,2],z=sphere_nodes3[t==0.4,3],colvar=color_out[t==0.2], col=heat.colors(24), colkey=list(length=0.5))
#
points3D(x=point_process2[,1]*1.1,y=point_process2[,2]*1.1,z=point_process2[,3]*1.1,col="black",add=TRUE, pch=4)

## ----pdfs,eval=FALSE-----------------------------------------------------
#  pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/ThreeSpheres.pdf",height=3)
#  par(mfrow=c(1,3))
#  scatter3D(x=sphere_nodes3[t==0,1],y=sphere_nodes3[t==0,2],z=sphere_nodes3[t==0,3],colvar=color_out[t==0],colkey=FALSE, col=heat.colors(24))
#  #
#  points3D(x=point_process1[,1]*1.1,y=point_process1[,2]*1.1,z=point_process1[,3]*1.1,col="black",add=TRUE, pch=4)
#  #
#  scatter3D(x=sphere_nodes3[t==0.2,1],y=sphere_nodes3[t==0.2,2],z=sphere_nodes3[t==0.2,3],colvar=color_out[t==0.2],colkey=FALSE, col=heat.colors(24))
#  #
#  points3D(x=point_process3[,1]*1.1,y=point_process3[,2]*1.1,z=point_process3[,3]*1.1,col="black",add=TRUE, pch=4)
#  #
#  scatter3D(x=sphere_nodes3[t==0.4,1],y=sphere_nodes3[t==0.4,2],z=sphere_nodes3[t==0.4,3],colvar=color_out[t==0.2], col=heat.colors(24), colkey=list(length=0.5))
#  #
#  points3D(x=point_process2[,1]*1.1,y=point_process2[,2]*1.1,z=point_process2[,3]*1.1,col="black",add=TRUE, pch=4)
#  dev.off()

