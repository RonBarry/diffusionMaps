## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(diffusionMaps)
library(spam)
library(RANN)
library(ptinpoly)
library(colorspace)
library(plot3D)

## ----sphere1, fig.height=6, fig.width=6----------------------------------
radius = 5
output = sphereNodes(N=200000,radius=radius)
sphere_nodes = output$sphere_nodes
angles = output$angles
longlat = output$longlat

## ----continentShape------------------------------------------------------
data(americaShape)
data(eurasiaShape)
data(antarticaShape)
#
outsideAm = ptinpoly::pip2d(americaShape, longlat)==(-1)
outsideAnt = ptinpoly::pip2d(antarcticaShape, longlat)<0
outsideEur = ptinpoly::pip2d(eurasiaShape, longlat)<0
index = outsideAm&outsideAnt&outsideEur
ocean_nodes = sphere_nodes[index,]

## ----sphere2-------------------------------------------------------------
outout = RANN::nn2(data = ocean_nodes, query = ocean_nodes, k = 5)
hist(outout$nn.dist[,2:5],n=50)
NN = nrow(ocean_nodes)
latt_buoy = spam(ncol=NN,nrow=NN,0)
temp = rep(NA,NN)
for(i in 1:NN){
  close_nodes = outout$nn.idx[i,2:5]
  close_nodes = close_nodes[outout$nn.dists[i,2:5]<0.4]
  latt_buoy[i,close_nodes] = 1L
}
  latt_buoy = sign(latt_buoy+t(latt_buoy))
  latt_buoy = spam::cleanup(latt_buoy)

#  Information about the sparse neighbor matrix latt_buoy
#
dim(latt_buoy)
isSymmetric(latt_buoy)
any(diag(latt_buoy) != 0)
table(as.vector(latt_buoy))
sparseness3 = length(latt_buoy)/dim(latt_buoy)[1]^2
cat("The proportion of non-zero in latt_buoy is ",sparseness3)
object.size(latt_buoy)
display(latt_buoy)

## ----part9---------------------------------------------------------------
#ff = "/Users/ronaldbarry/Desktop/Inactive Research #Folders/Three-Dee/NOAA-buoy-latest.txt"
#hold=read.table(ff,stringsAsFactors=FALSE)
#holder = hold[,c(1,2,3,4,5,6,7,19)]
#names(holder) = #c("station","lat","long","yr","mo","day","hour","water_temp")
#keep = (holder$water_temp!="MM")&(holder$hour==23)
#buoy_info = holder[keep,]
data(buoy_info)
Z = as.numeric(buoy_info[,"water_temp"])
cat("Number of buoys is ",length(Z),"\n")
#
ang_buoy = buoy_info[,c("lat","long")]
V = (pi/2)*(1-ang_buoy[,1]/90)
phi = pi*(1-ang_buoy[,2]/180)
locs_buoy = radius*cbind(sin(V)*cos(phi), sin(V)*sin(phi), cos(V))

## ----part10--------------------------------------------------------------
T_buoy = makeTranMatrix(latt_buoy, M=0.5)
#out_cross  = crossvalNparSmoother(T=T_buoy, 
#                     nodelocs = ocean_nodes, 
#                     locs=locs_buoy, Z=Z, k_max = 200)
#
#plot(out_cross$press,type="l")
#out_cross$k
smoother_output = nparSmoother(T=T_buoy, nodelocs = ocean_nodes, Z=Z, locs=locs_buoy, k = 40)
#
smoothed_temps = smoother_output[,"value"]
#
color = heat_hcl(36)[smoothed_temps+1]
#
#
par(mfrow=c(1,2))
plot(longlat[index,],cex=0.1,xlim=c(-200,200),
     ylab="latitude",xlab="longitude")
points(buoy_info$long,buoy_info$lat, pch=19, col=heat_hcl(36)[(0:11)*3 + 2])
plot(longlat[index,], pch=19,cex=0.5, col=color,
     xlim=c(-200,200),
     ylab="latitude",xlab="longitude")
points(buoy_info$long, buoy_info$lat,pch=19)
legend("right",legend=(1:11)*3, 
       pch=19,
       col = heat_hcl(36)[(1:11)*3+1],
       cex=0.7)
pdf("/Users/ronaldbarry/Desktop/diffusionMap paper/World.pdf", height=4)
par(mfrow=c(1,2))
plot(longlat[index,],cex=0.1,xlim=c(-200,200),
     ylab="latitude",xlab="longitude")
points(buoy_info$long, buoy_info$lat, pch=19, col=heat_hcl(36)[(0:11)*3 + 2])
plot(longlat[index,], pch=19,cex=0.5, col=color,
     xlim=c(-200,230),
     ylab="latitude",xlab="longitude")
legend("right",legend=(1:11)*3, 
       pch=19,
       col = heat_hcl(36)[(1:11)*3+1],
       cex=0.7)
dev.off()

