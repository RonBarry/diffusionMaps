#' Arrival times at Intensive Care Unit.
#'
#' The data consists of arrival times at an intensive care unit.
#' The data appeared originally in 'The Statistical Analysis of Series
#' of Events', by D.R. Cox and P.A.W. Lewis, Spottiswoode, Ballantyne
#' and Co. Ltd., London and Colchester 1966.  We combined the time data
#' from the dataset fisherB1 in the R package **circular** with hours
#' and days directly copied from the original text. The 'timeline' is
#' wrapped around the cyliner in the form of a spiral, with one turn
#' per 24 hours.
#'
#' @format A data frame with 254 rows and 5 variables:
#' \describe{
#'   \item{year}{year, starting with 1963}
#'   \item{month}{}
#'   \item{day}{}
#'   \item{hours}{}
#'   \item{mins}{}
#' }
"intensive_care"
