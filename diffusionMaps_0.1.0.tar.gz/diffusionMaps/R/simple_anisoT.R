#' Create simple anisotropic transition matrices.
#'
#' This function assumes a model where flow rate is isotropic in two
#' dimensions and different in the third dimension.  This works
#' well in situations such as lakes where we can have isotropy
#' E/W and N/S, but have a different vertical flow rate.  This model
#' also works with cylindrical data, where the axial flow rate is
#' different from the flow rate around the cylinder.
#'
#' The flow rate will depend on whether the neighbor relationship (as
#' defined by *latt*) is axial or not.  An axial neighbor has different
#' locations in the axial dimension.  All other neighbors (from *latt*)
#' are, not surprisingly, non-axial neighbors.
#'
#' The sparse matrix \code{latt}, which describes the neighbor relationship,
#' is assumed to contain only the values 0 and 1, is zero along the
#' diagonal, and is symmetric.  Symmetry isn't necessarily assumed by
#' other, alternative functions that create a transition matrix, but
#' \code{simple_anisoT} models anisotropic diffusion, so that flow
#' rates are the same both ways between pairs of nodes.  In fact, if
#' a non-symmetric \code{latt} or one with non-zero diagonal is passed
#' to \code{simple_anisoT}, the function will 'fix' the neighbor matrix
#' and throw a warning.
#'
#' Denote \code{axial_move} as \eqn{\theta}, then the transition matrix is
#' constructed this way:
#'
#'
#'
#'
#'
#' @param latt A sparse, symmetric neighbor matrix of 0s and 1s.
#' @param nodelocs A 3-column matrix of node locations.
#' @param axial_move Numeric variable between 0 and 1 that governs
#' the flow rate along the third dimension.
#' @param diff_dim Integer giving dimension with the axial flow rate.
#' @param nonaxial_move Numeric variable between 0 and 1 that governs
#' the flow rate along the non-axial dimensions.
#'
#' @return T A sparse transtion matrix (spam object).
#'
#' @family Transition matrix functions
#'
#' @import spam
#' @export
#' @examples
#'
#' latt = matrix(nrow=4,ncol=4, byrow=TRUE,
#'        c(0,1,0,0,1,0,1,0,0,1,0,1,0,0,1,0))
#' latt = as.spam(latt)
#' nodelocs = rbind(c(1,1,1),c(1,1,2),c(1,1,2),c(1,2,1))
#' simple_anisoT(latt, nodelocs, axial_move=0.2,
#'               nonaxial_move = 0.1)
#'
simple_anisoT = function(latt, nodelocs,
                         axial_move, diff_dim = 3,
                         nonaxial_move)
{
  #  Tests of latt
  latt = as.spam(latt)
  latt = spam::cleanup(latt)
  if(!isSymmetric(latt)){
    latt = sign(latt + t(latt))
    warning("The nbr matrix latt wasn't symmetric, simple_anisoT made it symmetric.")
  }
  if(max(abs(diag(latt)))>0){
    warning("The diagonal of latt should be zero, simple_anisoT made it symmetric.")
    diag(latt) = 0
  }
  #
  z = nodelocs[,diff_dim]
  temp = nodelocs[,-diff_dim]
  x = temp[,1]
  y = temp[,2]
  #  There are dense matrix computations here, don't know why
  latt_nonAxial = sign(abs(z%d*%latt - latt%*%diag.spam(z)))
  latt_axial = latt - latt_nonAxial
  #
  number_axial_nbr = colSums(latt_axial)
  number_nonax_nbr = colSums(latt_nonAxial)
  #
  #
  #  Now test that the two movement probabilites aren't
  #  too large.
  test = max(number_axial_nbr*axial_move +
               number_nonax_nbr*nonaxial_move)
  if(max(test)>1){
    warning("Either axial_move or nonaxial_move is too large.
            Movement probabilites exceed one!")
  }
  T = latt_nonAxial*nonaxial_move +
      latt_axial*axial_move
  T = as.spam(T)
  #  Now, the diagonal
  diag(T) = 1 - colSums(T) + diag(T)
  T
}
