#' Crossvalidation version of  nparSmoother
#'
#' The crossvalidation is based on the UCV statistic which is in Sain, Baggerly,
#' Scott (1994).  The probability \eqn{p_{i,-i}} is the probability at the node
#' closest to the ith observation computed from a diffusion map derived
#' from data with the ith observation removed.  Technically we use an estimator
#' proportional to the UCV, which is \eqn{\sum_{i=1}^N p_i + (2/n)\sum_{j=1}^n
#' p_{i,-i}}.  This is computed for each number of steps k up to \code{k_max}.
#'
#'
#' @param T Sparse transition matrix.
#' @param nodelocs 3-column matrix of node locations.
#' @param locs 3-column matrix of locations of data.
#' @param Z observed values at the data locations.
#' @param k_max Integer max number of steps for CV computation.
#'
#' @return A numeric vector of length \code{k_max} containing UCV values.
#'
#' @import spam
#' @import RANN
#' @export
#'
crossvalNparSmoother = function(T, nodelocs, locs, Z, k_max = 10)
{
  n_nodes <- nrow(nodelocs)
  n_observ = nrow(locs)
  #
  where_data = RANN::nn2(data = nodelocs, query = locs, k = 1)
  which_nodes = as.vector(where_data$nn.idx)
  p0_deleted = matrix(nrow=n_nodes, ncol=n_observ,NA)
  for(i in 1:n_observ){
    where_deleted_data = which_nodes[-i]
    p0_deleted[,i] =
      as.vector(tabulate(where_deleted_data,nbins=n_nodes)/(n_observ-1))
  }
  z0_deleted = matrix(nrow=n_nodes, ncol=n_observ,NA)
  un_which_nodes = unique(which_nodes)
  for(i in 1:n_observ)
  {
    z0_temp = rep(0,n_nodes)
    for(k in 1:length(which_nodes))
    {
      z0_temp[which_nodes[k]] = z0_temp[which_nodes[k]] +
        Z[k]
    }
    z0_temp[which_nodes[i]] = z0_temp[which_nodes[i]] - Z[i]
    z0_deleted[,i] = z0_temp/(n_observ-1)
  }
  #
  #
  pk_deleted = p0_deleted
  zk_deleted = z0_deleted
  press = rep(NA,k_max)
  for (k in 1:k_max) {
    pk_deleted = T%*%pk_deleted
    zk_deleted = T%*%zk_deleted
    deleted_probs = pk_deleted[cbind(which_nodes,1:n_observ)]
    deleted_z = zk_deleted[cbind(which_nodes,1:n_observ)]
    deleted_preds = deleted_z/deleted_probs
    deleted_preds[is.nan(deleted_preds)] = mean(Z)
    press[k] = sum((Z - deleted_preds)^2)
  }
  #
  out = list(press = press,
             k = which.min(press))
  out
}
