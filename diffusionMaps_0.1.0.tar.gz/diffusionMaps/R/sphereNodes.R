#' Nearly equispaced nodes on a sphere.
#'
#' sphereNodes produces a set of nodes in 3-d
#' that covers the sphere with reasonable spacing,
#' using the algorithm from
#' \url{https://www.cmu.edu/biolphys/deserno/pdf/sphere_equi.pdf}.
#' Note that you won't usually get N nodes in the output, but
#' instead a number of nodes somewhat less than N.  However, larger
#' N should give a larger number of nodes.
#'
#'
#' @param N A target value for the number of nodes produced.
#' @param radius The radius of the sphere.
#'
#' @return A list with node information.
#' \item{sphere_nodes}{A three column matrix of x,y,z node locations.}
#' \item{angles}{A two column matrix of angles for each node.}
#' \item{longlat}{A two column matrix of lat and long for each node.}
#'
#' @export
#
sphereNodes = function(N,radius)
{
sphere_nodes = matrix(ncol=3,nrow=N,NA)
angles = matrix(ncol=2,nrow=N,NA)
#
N_count = 0
ang = 4*pi*radius^2/N
M_v = round(pi/sqrt(ang))
d_v = pi/M_v
d_phi = ang/d_v
for(m in 0:(M_v-1)){
  V = pi*(m+0.5)/M_v
  M_phi = round(2*pi*sin(V)/d_phi)
  for (n in 0:(M_phi - 1)){
    phi = 2*pi*n/M_phi
    N_count = N_count + 1
    sphere_nodes[N_count,] =
      radius*c(sin(V)*cos(phi), sin(V)*sin(phi), cos(V))
    angles[N_count,] = c(phi,V)
  }
}
indexNotNA = !is.na(sphere_nodes[,1])
sphere_nodes = sphere_nodes[indexNotNA,]
angles = angles[indexNotNA,]
latitudes = 90*((pi/2)-angles[,2])/(pi/2)
longitudes = 180*(pi - angles[,1])/pi
longlat = cbind(longitudes,latitudes)
#
output = list(sphere_nodes = sphere_nodes,
              angles = angles,
              longlat = longlat)
output
}
