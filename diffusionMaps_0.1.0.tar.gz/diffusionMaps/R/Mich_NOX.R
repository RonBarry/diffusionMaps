#' Lake Michigan Oxidized Nitrogen.
#'
#' This data was extracted from National Oceanic and
#' Atmospheric Administration Great Lakes Monitoring
#' Program. Available at: https://www.ndbc.noaa.gov/
#' It consists of oxidized nitrogen concentration at
#' various locations and depths in Lake Michigan.
#'
#' @format A data frame with 162 rows and 8 variables:
#' \describe{
#'   \item{year}{}
#'   \item{month}{}
#'   \item{stationID}{}
#'   \item{station.depth}{m}
#'   \item{latitude}{}
#'   \item{longitude}{}
#'   \item{sample.depth}{m}
#'   \item{totalOxiN}{mg/l}
#' }
"Mich_NOX"
