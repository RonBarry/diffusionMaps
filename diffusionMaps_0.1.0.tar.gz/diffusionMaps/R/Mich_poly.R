#' Lake Michigan polygon.
#'
#' This is a shapefile (polygon) of the outline of Lake Michigan,
#' in longitude and latitude.
#'
#' @format A data frame with 1538 rows and 2 variables:
#' \describe{
#'   \item{longitude}{}
#'   \item{latitude}{}
#' }
"Mich_poly"
