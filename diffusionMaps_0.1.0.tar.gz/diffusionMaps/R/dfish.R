#' Density of the Fisher distribution on a sphere.
#'
#' The function takes in x,y,z values on a sphere
#' and produces the value of the Fisher density.
#'
#'
#' The formula for the Fisher density was from the wikipedia entry on
#' the Von Mises-Fisher distribution, for the case of p = 3.
#'
#'
#' @param X three columns, x,y,z locations on the surface of a sphere.
#' @param mu location of the center of the distribution.
#' @param k concentration parameter of the distribution.
#'
#'
#' @export
#'
dfish = function(X, mu, k)
{
  NN = nrow(X)
  densities = rep(NA,NN)
  for(i in 1:NN)
    {
      x = X[i,]/sqrt(sum(X[i,]^2))
      const = k/(2*pi*(exp(k)-exp(-k)))
      densities[i] = const*exp(k*mu%*%x)
    }
  densities
}
