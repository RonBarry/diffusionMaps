#' Crossvalidation version of  nparDensity
#'
#' The crossvalidation is based on the UCV statistic which is in Sain, Baggerly,
#' Scott (1994).  The probability \eqn{p_{i,-i}} is the probability at the node
#' closest to the ith observation computed from a diffusion map derived
#' from data with the ith observation removed.  Technically we use an estimator
#' proportional to the UCV, which is \eqn{\sum_{i=1}^N p_i^2 + (2/n)\sum_{j=1}^n
#' p_{i,-i}}.  This is computed for each number of steps k up to \code{k_max}.
#'
#'
#' @param T Sparse transition matrix.
#' @param nodelocs 3-column matrix of node locations.
#' @param locs 3-column matrix of locations of data.
#' @param k_max Integer max number of steps for CV computation.
#'
#' @return A numeric vector of length \code{k_max} containing UCV values.
#'
#' @import spam
#' @import RANN
#' @export
#'
crossvalNparDensity = function(T, nodelocs, locs, k_max = 10)
{
  n_nodes <- nrow(nodelocs)
  n_observ = nrow(locs)
  #
  where_data = RANN::nn2(data = nodelocs, query = locs, k = 1)
  which_nodes = as.vector(where_data$nn.idx)
  p0_deleted = matrix(nrow=n_nodes, ncol=n_observ,NA)
  p0 = tabulate(which_nodes ,nbins = n_nodes)/n_observ
  for(i in 1:n_observ){
    where_data = which_nodes[-i]
    p0_deleted[,i] = as.vector(tabulate(where_data,nbins=n_nodes)/(n_observ-1))
  }
  #
  #
  ucv = rep(NA,k_max)
  pk = as.vector(p0)
  pk_deleted = p0_deleted
  for (k in 1:k_max) {
    pk = T%*%pk
    pk_deleted = T%*%pk_deleted
    deleted_probs = diag(pk_deleted[cbind(which_nodes,1:n_observ)])
    ucv[k] = sum(pk^2) - (2/n_observ)*sum(deleted_probs)
  }
  #
  out = list(ucv = ucv,
             k = which.min(ucv))
  out
}
