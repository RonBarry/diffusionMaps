#' Eurasia and Africa polygon.
#'
#' This is a shapefile (polygon) of the outline of Eurasia
#' and Africa in longitude and latitude.
#'
#' @format A data frame with 200 rows and 2 variables:
#' \describe{
#'   \item{latitude}{}
#'   \item{longitude}{}
#' }
"eurasiaShape"
