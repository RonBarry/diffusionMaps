#' NOAA Buoy Data.
#'
#' A set of observed water temperatures at 11 p.m.
#' on 5 Aug 2019.  From NOAA network of moored buoys.
#'
#' @format A data frame with 359 rows and 8 variables:
#' \describe{
#'   \item{station}{}
#'   \item{lat}{}
#'   \item{long}{}
#'   \item{yr}{}
#'   \item{mo}{}
#'   \item{day}{}
#'   \item{hour}{}
#'   \item{water_temp}{C}
#' }
"buoy_info"
