#'  Prepares a lattice plot
#'
#'  \code{plotMesh} creates matrices that can be used
#'  to plot segments between 3-d node locations, corresponding
#'  to neighbors as defined by the sparse matrix *latt*.
#'
#'
#' @param latt A spam object, symmetric, with 1 for neighbors, 0 otherwise.
#' @param nodelocs Three column matrix of locations.
#'
#' @import spam
#'
#' @export
#'
plotMesh = function(latt,nodelocs){
  n = latt@dimension[1]
  num_segments = length(latt@entries)
  indices =
    cbind(rep.int(1:n,diff(latt@rowpointers)),latt@colindices)
  for(i in 1:num_segments){
}
  start = nodelocs[indices[,1],]
  finish = nodelocs[indices[,2],]
  start_index = indices[,1]
  finish_index = indices[,2]
  out = list(start=start, finish=finish,
             start_index = start_index,
             finish_index = finish_index)
  out
}
